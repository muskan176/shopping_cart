Welcome to the Women's Clothing Ecommerce Website
Here are a few simple steps to follow:
****************************************************************************************************************
 step 1: Check for the LOGIN option (navbar ,landing page) 
         If you are a member enter the email and password, if not go to step 2
 step 2: Check for CreateAccount option 
         Enter your Name, Email, Password, confirm your password then click on Register button.
         Click on lOGIN
 step 3: Users cannot register to become Admins.
         If you are an Admin  then click on  Admin Login in the login page .
         Enter the Email and Password to Login succesfully.
 Step 4: Only after successfull Login , user will be directed to the Shopping Cart page.
         Click on the Add Cart button to add each products and also enter the quantity . 
         You can see the total of the products going to be purchased.
 Step 5: Enter the Customer Details to checkout.
         Click on Cash On Delivery and purchase option to finally checkout the items in the cart.
*****************************************************************************************************************      